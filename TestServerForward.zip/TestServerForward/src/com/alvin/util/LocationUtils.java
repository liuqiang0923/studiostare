package com.alvin.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONObject;

public class LocationUtils {

	private static final String SINA_REQS_URL = "http://ip.taobao.com/service/getIpInfo.php?ip="; //218.192.3.42
	
	public static boolean isChina(String ip) {
		try {
			if (ip == null || "".equals(ip) || "127.0.0.1".equals(ip) || ip.contains("0:0:0:0")) return true;
			URL reqUrl = new URL(SINA_REQS_URL+ip);
			HttpURLConnection connect = (HttpURLConnection) reqUrl.openConnection();
			InputStream in = connect.getInputStream();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buff = new byte[256];
			int rc = 0;
			while ((rc = in.read(buff, 0, 256)) > 0) {
				out.write(buff, 0, rc);
			}
			//System.out.println(new String(out.toByteArray(), "UTF8"));
			JSONObject json = new JSONObject(new String(out.toByteArray(), "UTF8"));
			JSONObject data = json.getJSONObject("data");
			String countryId = data.getString("country_id");
			//System.out.println(countryId);
			return "CN".equalsIgnoreCase(countryId);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public static void main(String[] args) {
		isChina("218.192.3.42");
	}
	
}
